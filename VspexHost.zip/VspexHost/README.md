# VSPEXHOST

VSPEXHOST is a simple Python web server framework designed to handle basic web requests. It features routing, logging, and an optional graphical interface. This can be used for purposes.

## Installation

To install VSPEXHOST, run:

```bash
pip install vspexhost


